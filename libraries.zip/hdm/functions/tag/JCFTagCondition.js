/* @org.eclipse.vjet.dsf.resource.utils.CodeGen("VjoGenerator") */
vjo.etype('hdm.functions.tag.JCFTagCondition') //< public
.satisfies('java.io.Serializable')
.values("SUCCESS, FAILURE, ANY")
.endType();