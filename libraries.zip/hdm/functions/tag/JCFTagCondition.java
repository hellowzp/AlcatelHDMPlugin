package hdm.functions.tag;

import java.io.Serializable;

public enum JCFTagCondition
  implements Serializable
{
  SUCCESS, FAILURE, ANY;
}