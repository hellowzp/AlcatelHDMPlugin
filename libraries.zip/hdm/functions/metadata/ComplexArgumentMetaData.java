package hdm.functions.metadata;

public class ComplexArgumentMetaData extends ArgumentMetaData
{
  private String label;

  public String getLabel()
  {
    return this.label;
  }
  public void setLabel(String label) {
    this.label = label;
  }
}