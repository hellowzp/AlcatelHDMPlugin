package hdm.functions.types.response;

import java.io.Serializable;

public class ScheduleDownloadResponseDTO
  implements ResponseDTO, Serializable
{
  private static final long serialVersionUID = -1954799496441168125L;
}