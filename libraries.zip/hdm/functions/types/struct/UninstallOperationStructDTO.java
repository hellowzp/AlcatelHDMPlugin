package hdm.functions.types.struct;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="uninstallOperationStructDTO")
public class UninstallOperationStructDTO extends OperationStructDTO
{
}