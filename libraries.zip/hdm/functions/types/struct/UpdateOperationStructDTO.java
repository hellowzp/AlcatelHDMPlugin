package hdm.functions.types.struct;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="updateOperationStructDTO")
public class UpdateOperationStructDTO extends OperationStructDTO
{
}